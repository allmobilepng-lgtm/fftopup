@extends('layout.master')
@section('title')
    {{ $settings->home_title }}
@endsection
@section('content')
<div>
    <div class="p-2">
        @if ($settings->enable_notice)
        <div class="notice-container container m-auto">
            <div class="alert alert-light notice-style alert-dismissible fade show position-relative shadow-lg border-0 animate-notice" role="alert" id="noticeBox">
                <button type="button" class="custom-close-btn" id="closeNotice" aria-label="Close">
                    <span>&times;</span>
                </button>
                <div class="notice-heading">{{ $settings->notice_title }}</div>
                <div class="notice-text mb-0">{{ $settings->notice_content }}</div>
            </div>
        </div>
        @endif

@if (count($sliders) > 0)
<section class="container m-auto">
  <section class="carousel my-4" dir="ltr" aria-label="Gallery" tabindex="0" style="margin-bottom:10px !important;">
    <div class="carousel__viewport">
      <ol class="carousel__track" style="transform: translateX(0px); transition: all 0ms ease 0s;">
        @foreach ($sliders as $slider)
        <li class="carousel__slide">
          <div class="carousel__item">
            @isset($slider->url)
            <a href="{{ $slider->url }}" target="_blank">
              <img src="{{ get_image($slider->image_url) }}" class="rounded-md">
            </a>
            @else
            <img src="{{ get_image($slider->image_url) }}" class="rounded-md">
            @endisset
          </div>
        </li>
        @endforeach
      </ol>
    </div>
    <ol class="carousel__pagination">
      @if (count($sliders) > 0)
        @for($i = 1; $i <= count($sliders); $i++)
          <li class="carousel__pagination-item">
            <button type="button" class="carousel__pagination-button {{ $i == 1 ? 'carousel__pagination-button--active' : '' }}" aria-label="Navigate to slide {{ $i }}"></button>
          </li>
        @endfor
      @endif
    </ol>
  </section>
</section>
@endif

        <!--- products --->
        @foreach($categorys as $category)
        <section class="my-2" id="topup">
            <div class="container mx-auto">
                <div class="text-center">
                    <div class="flex items-center justify-center px-4 mt-0 md:mt-2 section-contact-gap pb-4">
                        <h3 class="text-2xl sm:text-3xl text-center font-primary font-bold mx-4 text-secondary-900">
                            {{ $category->title }}
                        </h3>
                    </div>
                </div>

                <div class="pb-1 md:pb-10">
                    <div class="md:py-5 md:px-0 grid md:grid-cols-6 sm:grid-cols-4 grid-cols-3 md:gap-8 gap-4">
                        @foreach ($products->where('categorie_id', $category->id) as $product)
                        <div class="single-game-product mb-2 md:mb-6">
                            <a href="{{ route('topup', $product->slug) }}" class="triangle">
                                <div class="cursor-pointer">
                                    <div class="inset-0 opacity-25"></div>
                                    <div class="inset-0 transform hover:scale-90 transition duration-300">
                                        <div class="h-full w-full text-center mx-auto">
                                            <img src="{{ get_image($product->image) }}" class="rounded-md">
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <h1 class="capitalize text-xs text-center pt-3 font-primary font-extralight text-secondary-500">{{$product->title}}</h1>
                                </div>
                            </a>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>
        @endforeach

        

        

        <script src="{{ asset('assets/template/js/slider.js') }}"></script>
    </div>
</div>
@endsection

@push('js')
<script>
document.addEventListener('DOMContentLoaded', () => {
    const notice = document.getElementById('noticeBox');
    const closeBtn = document.getElementById('closeNotice');

    if (notice) {
        // Fade-in animation
        notice.style.opacity = 0;
        setTimeout(() => {
            notice.style.transition = "opacity 1s ease, transform 0.5s ease";
            notice.style.opacity = 1;
            notice.style.transform = "translateY(0)";
        }, 100);
    }

    // Close button fade-out
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            notice.style.transition = "opacity 0.6s ease, transform 0.6s ease";
            notice.style.opacity = 0;
            notice.style.transform = "translateY(-20px)";
            setTimeout(() => notice.remove(), 600);
        });
    }
});
</script>
@endpush

@push('style')
<style>
.notice-container {
    max-width: 700px;
}

.notice-style {
    background-color: {{ $settings->notice_background_color }};
    color: {{ $settings->notice_font_color }};
    border-left: 5px solid rgba(0, 0, 0, 0.15);
    border-radius: 12px;
    padding: 20px 25px 20px 25px;
    font-family: "Poppins", sans-serif;
    position: relative;
    overflow: hidden;
    transform: translateY(-10px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* কাস্টম Close বাটন */
.custom-close-btn {
    position: absolute;
    top: 12px;
    right: 12px;
    background: rgba(255,255,255,0.2);
    border: none;
    border-radius: 50%;
    width: 28px;
    height: 28px;
    color: {{ $settings->notice_font_color }};
    font-size: 18px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
    box-shadow: 0 0 0 rgba(255,255,255,0);
}

.custom-close-btn:hover {
    background: rgba(255,255,255,0.4);
    transform: rotate(90deg) scale(1.1);
    box-shadow: 0 0 8px rgba(255,255,255,0.7);
}

.custom-close-btn span {
    display: block;
    transform: translateY(-1px);
    font-weight: bold;
}

/* Light reflection animation */
.notice-style::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 60%;
    height: 100%;
    background: linear-gradient(120deg, rgba(255,255,255,0.3), transparent);
    animation: shine 4s infinite linear;
}
@keyframes shine {
    0% { left: -100%; }
    50% { left: 100%; }
    100% { left: 100%; }
}

.notice-style:hover {
    transform: scale(1.02);
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}

.notice-style .notice-heading {
    font-size: 18px;
    font-weight: 600;
    padding-bottom: 6px;
}

.notice-text {
    font-size: 13px;
    font-weight: 400;
    font-family: "Times New Roman", Times, serif;
}
</style>
<style>
    /* ---------------------------------------------------------------------- */
    /* CSS Styles */
    /* ---------------------------------------------------------------------- */
    
    /* FAB Wrapper - সমস্ত বাটনকে ফ্লোটিং পজিশনে (ডান-নিচে) সেট করে */
    .fab-wrapper {
        position: fixed;
        bottom: 80px; /* নিচের থেকে দূরত্ব: 80px */
        right: 15px; 
        z-index: 1000;
        display: flex;
        flex-direction: column-reverse; /* বাটনগুলিকে উল্টো ক্রমে সাজায় */
        align-items: flex-end;
        gap: 8px; 
    }

    /* Main Toggle Button ("সাহায্য লাগবে ?") */
    .fab-toggle {
        display: flex;
        align-items: center;
        background-color: #E23D3A; /* লাল রঙ */
        color: white;
        border-radius: 25px; 
        padding: 0 15px 0 15px;
        height: 50px;
        cursor: pointer;
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
        transition: all 0.3s ease;
        position: relative; 
        justify-content: center; 
    }

    .fab-toggle .fab-text {
        font-size: 14px;
        font-weight: bold;
        margin-right: 8px;
        white-space: nowrap;
        opacity: 1; 
        transition: opacity 0.3s ease, margin 0.3s ease, width 0.3s ease;
    }

    .fab-toggle .fab-icon {
        width: 24px;
        height: 24px;
        transition: margin 0.3s ease;
    }

    /* Contact Links Container (শুরুতে লুকানো থাকবে) */
    .fab-links {
        display: flex;
        flex-direction: column-reverse;
        gap: 8px;
        opacity: 0; 
        transform: translateY(10px); 
        pointer-events: none; 
        transition: opacity 0.3s ease, transform 0.3s ease;
    }

    .fab-links.visible {
        opacity: 1; /* দৃশ্যমান */
        transform: translateY(0); 
        pointer-events: auto; 
    }

    /* Individual FAB Links (WhatsApp, Telegram, Phone) */
    .fab-link {
        width: 45px; 
        height: 45px; 
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        cursor: pointer;
        transition: transform 0.2s ease;
    }

    .fab-link img {
        width: 22px; 
        height: 22px;
        filter: brightness(0) invert(1); 
    }

    /* Specific colors */
    .fab-phone {
        background-color: #E23D3A; /* ফোন বাটন লাল */
    }
    .fab-whatsapp {
        background-color: #25D366; 
    }
    .fab-telegram {
        background-color: #0088CC; 
    }
    
    /* যখন FABটি expand হবে, তখন Main Button-এর পরিবর্তন */
    .fab-wrapper.expanded .fab-toggle {
        width: 45px; /* গোলাকার হবে */
        height: 45px;
        padding: 0; 
        border-radius: 50%; 
    }

    .fab-wrapper.expanded .fab-toggle .fab-text {
        opacity: 0; 
        width: 0; 
        overflow: hidden; 
        margin-right: 0; 
    }
    
    .fab-wrapper.expanded .fab-toggle .fab-icon {
        margin: 0; 
    }
    
    .carousel__item img {
    border-radius: 4px; /* হালকা curve */
}
</style>
<style>
.carousel__item img {
    border-radius: 0 !important;
}
</style>

{{-- ---------------------------------------------------------------------- --}}
{{-- HTML Structure (Blade Syntax) --}}
{{-- ---------------------------------------------------------------------- --}}
<div class="fab-wrapper">
    {{-- Main Toggle Button: "সাহায্য লাগবে ?" লেখা ও ফোন আইকন সহ (Toggle Button) --}}
    <div class="fab-toggle" id="mainFabButton">
        <span class="fab-text">সাহায্য লাগবে ?</span>
        <img class="fab-icon" src="https://img.icons8.com/ios-filled/50/FFFFFF/phone.png" alt="Phone">
    </div>

    {{-- Contact Links Container: ক্লিক করার পর এই বাটনগুলি দেখা যাবে --}}
    {{-- ক্রম: সবার উপরে Phone Call, তার নিচে Telegram, সবার নিচে WhatsApp --}}
    <div class="fab-links" id="contactLinks">
        
    
        
        {{-- 2. টেলিগ্রাম বাটন --}}
        @if(isset($settings->telegram_link))
        <a href="{{ $settings->telegram_link }}" class="fab-link fab-telegram" target="_blank">
            <img src="https://img.icons8.com/ios-filled/50/FFFFFF/telegram-app.png" alt="Telegram">
        </a>
        @endif
        
        {{-- 3. হোয়াটসঅ্যাপ বাটন (সবার নিচে) --}}
        @if(isset($settings->whatsapp_number))
        <a href="https://wa.me/{{ $settings->whatsapp_number }}" class="fab-link fab-whatsapp" target="_blank">
            <img src="https://img.icons8.com/ios-filled/50/FFFFFF/whatsapp.png" alt="WhatsApp">
        </a>
        @endif

        {{-- ক্যানসেল বাটন (X) বাদ দেওয়া হয়েছে --}}
    </div>
</div>

<script>
    // ----------------------------------------------------------------------
    // JavaScript Logic (Toggle Functionality)
    // ----------------------------------------------------------------------
    document.addEventListener('DOMContentLoaded', function() {
        const mainFabButton = document.getElementById('mainFabButton');
        const contactLinks = document.getElementById('contactLinks');
        const fabWrapper = document.querySelector('.fab-wrapper'); 

        // ফাংশন যা বাটনগুলি দেখাবে/লুকাবে (Toggle)
        mainFabButton.addEventListener('click', function() {
            // যদি visible ক্লাস না থাকে, তবে যোগ করে দেখাবে; অন্যথায় সরিয়ে লুকিয়ে দেবে।
            if (!contactLinks.classList.contains('visible')) {
                // Show links
                contactLinks.classList.add('visible');
                fabWrapper.classList.add('expanded'); 
            } else {
                // Hide links
                contactLinks.classList.remove('visible');
                fabWrapper.classList.remove('expanded'); 
            }
        });
        
        // যেহেতু ক্যানসেল বাটন নেই, তাই hide করার জন্য অন্য কোনো লিসেনার দরকার নেই।
    });
</script>
@endpush