<?php  
  
namespace App\Http\Controllers\Gateway;  
  
use App\Library\UddoktaPay;  
use App\Http\Controllers\Controller;  
use Illuminate\Support\Facades\Auth;  
use Exception;  
use Illuminate\Http\Request;  
  
class PaymentController extends Controller  
{  
    /**
     * Initiates the deposit payment process.
     */
    public function deposit(Request $request) {  
      
      $request->validate([  
          'amount' => 'required|numeric|min:1'  
      ]);  
        
      $user = Auth::user();  
      $amount = $request->amount;  
        
      // UddoktaPay requires a full route for success and cancel.
      $success_url = route('payment'); 
      $cancel_url = route('cancel.payment');  
        
      $requestData = [  
            'cus_name'    => $user->name,  
            'cus_email'   => $user->email,  
            'amount'       => $amount,  
            'metadata'     => [  
                'user_id' => $user->id,
                'amount' => $amount,  
                'type' => 'deposit' // Key to identify deposit transaction
            ],  
            'success_url'  => $success_url,  
            'cancel_url'    => $cancel_url,  
        ];  
  
        try {  
            $paymentUrl = UddoktaPay::init_payment($requestData);  
            return redirect($paymentUrl);  
        } catch (Exception $e) {  
            // Log the exception for debugging
            \Log::error('Deposit Initiation Error: ' . $e->getMessage());
            return back()->with('message', 'Payment initiation failed: ' . $e->getMessage())->with('message_type', 'error');
        }  
    }  
      
    /**
     * Handles the callback for successful deposit payment verification.
     */
    public function payment(Request $request) {  
        
        // UddoktaPay sends invoice_id as query parameter (or POST data depending on return_type)
        $invoiceId = $request->query('invoice_id') ?? $request->input('invoice_id');
        
        if (empty($invoiceId)) {  
            return redirect()->route('addfunds')->with('message', 'Invalid Payment Request.')->with('message_type', 'error');
        }  
        
        try {
            $data = UddoktaPay::verify_payment($invoiceId);  

            if (isset($data['status']) && $data['status'] == 'COMPLETED') {  
                // Metadata is already an array in the response, not a JSON string
                $metadata = is_array($data['metadata']) ? $data['metadata'] : json_decode($data['metadata'], true);  
                $amount = $metadata['amount'] ?? 0;  
                $user = Auth::user(); // Re-authenticate or ensure user is logged in if necessary

                if ($amount > 0) {
                    // Increment the user's balance
                    $user->increment('balance', $amount);
                    return redirect()->route('addfunds')->with('message', 'Deposit Successful.')->with('message_type', 'success');  
                } else {
                    return redirect()->route('addfunds')->with('message', 'Deposit Failed: Invalid amount.')->with('message_type', 'error');
                }
            } else {  
                // Payment not completed or failed
                return redirect()->route('addfunds')->with('message', 'Deposit failed.')->with('message_type', 'error');  
            }
        } catch (Exception $e) {
            \Log::error('Deposit Verification Error: ' . $e->getMessage());
            return redirect()->route('addfunds')->with('message', 'Payment verification error.')->with('message_type', 'error');
        }
    }  
      
    /**
     * Handles payment cancellation.
     */
    public function payment_cancel(Request $request) {  
      return redirect()->route('home')->with('message', 'Payment was cancelled.')->with('message_type', 'info');
    }  
}