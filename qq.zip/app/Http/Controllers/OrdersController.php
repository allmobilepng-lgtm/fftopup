<?php

namespace App\Http\Controllers;

use App\Constants\Status;
use App\Constants\OrderStatus;
use App\Constants\TopupProvider;
use App\Library\UddoktaPay;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Exception;
use App\Models\Order;
use App\Models\Variation;
use App\Models\Voucher;
use App\Models\User;

class OrdersController extends Controller
{
    public function buynow(Request $request)
    {
        $variation = Variation::where('stock', '>', 0)
            ->with(['product', 'vouchers' => function ($query) {
                $query->where('status', Status::AVAILABLE);
            }])
            ->findOrFail($request->variation_id);

        $quantity = $request->input('quantity', 1);

        if ($variation->product->isVoucher() && $variation->vouchers->count() < $quantity) {
            return back()->with('error', __('Sorry, this voucher is out of stock.'));
        }

        $amount_cal = round($variation->price * $quantity, 2);
        $profit_cal = max(0, $amount_cal - ($variation->buy_rate * $quantity));
        $profit_cal = number_format($profit_cal, 2, '.', '');

        $orderData = [
            'user_id'      => Auth::id(),
            'product_id'   => $variation->product->id,
            'variation_id' => $variation->id,
            'quantity'     => $quantity,
            'amount'       => $amount_cal,
            'profit'       => $profit_cal,
        ];

        if (in_array($variation->product->type, [Status::TOPUP, Status::INGAME, Status::SUBSCRIPTION])) {
            $orderData['account_info'] = $request->input('account_info');
        }

        // --- Wallet Payment Logic ---
        if (gs()->wallet && $request->payment_method === Status::WALLET) {
            try {
                if ($amount_cal > Auth::user()->balance) {
                    throw new Exception(('Insufficient Balance.'));
                }

                $vouchers = null;
                if ($variation->product->isVoucher()) {
                    $vouchers = Voucher::where('status', Status::AVAILABLE)
                        ->where('variation_id', $variation->id)
                        ->limit($quantity)
                        ->orderBy('id', 'DESC')
                        ->get();

                    if ($vouchers->count() < $quantity) {
                        throw new Exception(('Insufficient vouchers available.'));
                    }
                }

                DB::transaction(function () use ($orderData, $vouchers, $quantity, $variation) {
                    $order = Order::create($orderData);
                    $order->status = $order->product->isVoucher() ? Status::COMPLETE : Status::PROCESSING;
                    $order->update();

                    $user = Auth::user();
                    $user->balance -= $order->amount;
                    $user->save();

                    $accInfo = $order->account_info;
                    $sendNumber = is_array($accInfo) ? implode(' | ', $accInfo) : ($accInfo ?? 'Wallet Balance');

                    DB::table('transactions')->insert([
                        'user_gmail'     => $user->email,
                        'method'         => 'wallet',
                        'sendnumber'     => $sendNumber,
                        'transaction_id' => 'WAL-' . strtoupper(Str::random(12)),
                        'amount'         => $order->amount,
                        'order_id'       => $order->id,
                        'page'           => 'Check Out Page',
                        'status'         => 'paid',
                        'time_paid'      => now(),
                        'created_at'     => now(),
                        'updated_at'     => now(),
                    ]);

                    if ($order->product->isVoucher()) {
                        $variation->stock -= $vouchers->count();
                        $variation->save();

                        $voucherCodes = [];
                        foreach ($vouchers as $voucher) {
                            $voucherCodes[] = is_array($voucher->code) ? implode(',', $voucher->code) : $voucher->code;
                            $voucher->status = Status::SOLD;
                            $voucher->order_id = $order->id;
                            $voucher->save();
                        }
                        $order->voucher_code = implode(', ', $voucherCodes);
                        $order->update();
                    } else {
                        $variation->stock -= $quantity;
                        $variation->save();
                    }

                    $this->handleReseller($order);

                    try {
                        if ($order->product->isTopup() && $order->variation->isAutomatic() && gs()->enable_auto_topup) {
                            if (gs()->topup_provider === TopupProvider::HUMAYUN) {
                                $this->sendHumayunWebhook($order);
                            } else {
                                $this->autoTopup($order, $variation->provider_product_id);
                            }
                        } else {
                            $this->sendNotification("New Order: ID {$order->id}, Amount {$order->amount}");
                        }
                    } catch (Exception $e) { }
                });

                $redirect = $variation->product->isVoucher() ? route('codes') : route('orders');
                if ($request->ajax() || $request->wantsJson()) {
                    return response()->json(['success' => true, 'redirect_url' => $redirect, 'message' => 'Order Successful.']);
                }
                return redirect($redirect)->with('message', 'Order Successful.')->with('message_type', 'success');

            } catch (Exception $exception) {
                if ($request->ajax() || $request->wantsJson()) {
                    return response()->json(['success' => false, 'message' => $exception->getMessage()], 400);
                }
                return back()->with('message', $exception->getMessage())->with('message_type', 'error');
            }
        }

        return $this->processUddoktaPay($variation, $orderData, $request);
    }

    private function processUddoktaPay($variation, $orderData, $request)
    {
        $user = Auth::user();
        $requestData = [
            'cus_name'     => $user->name ?? 'Guest User',
            'cus_email'    => $user->email ?? 'noemail@example.com',
            'amount'       => $orderData['amount'],
            'metadata'     => [
                'account_info' => $request->input('account_info'),
                'variation_id' => $variation->id,
                'quantity'     => $orderData['quantity'],
                'user_id'      => $user->id,
                'type'         => 'order'
            ],
            'success_url'  => route('payment.success'),
            'cancel_url'   => route('cancel.payment'),
        ];

        try {
            $paymentUrl = UddoktaPay::init_payment($requestData);
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json(['success' => true, 'payment_url' => $paymentUrl]);
            }
            return redirect($paymentUrl);
        } catch (Exception $e) {
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json(['success' => false, 'message' => $e->getMessage()], 400);
            }
            return back()->with('message', $e->getMessage())->with('message_type', 'error');
        }
    }

    public function paymentSuccess(Request $request)
    {
        $invoiceId = $request->query('invoice_id') ?? $request->input('invoice_id');
        if (empty($invoiceId)) {
            return redirect()->route('orders')->with('message', 'Invalid Invoice.')->with('message_type', 'error');
        }
        
        try {
            $data = UddoktaPay::verify_payment($invoiceId);
        } catch (Exception $e) {
            return redirect()->route('orders')->with('message', 'Verification Failed.')->with('message_type', 'error');
        }

        if (isset($data['status']) && $data['status'] === 'COMPLETED') {
            $metadata = is_array($data['metadata']) ? $data['metadata'] : json_decode($data['metadata'], true);
            
            if (!is_array($metadata) || ($metadata['type'] ?? null) !== 'order') {
                return redirect()->route('orders')->with('message', 'Invalid metadata.')->with('message_type', 'error');
            }
            
            DB::beginTransaction();
            try {
                $variation = Variation::with('product')->findOrFail($metadata['variation_id']);
                $quantity  = $metadata['quantity'];
                
                $order = Order::create([
                    'user_id'      => $metadata['user_id'],
                    'product_id'   => $variation->product->id,
                    'variation_id' => $variation->id,
                    'quantity'     => $quantity,
                    'amount'       => $data['amount'],
                    'profit'       => number_format(max(0, $data['amount'] - ($variation->buy_rate * $quantity)), 2, '.', ''),
                    'account_info' => $metadata['account_info'],
                ]);

                $order->status = $variation->product->isVoucher() ? Status::COMPLETE : Status::PROCESSING;
                $order->save();

                $accInfo = $metadata['account_info'];
                $displayNumber = is_array($accInfo) ? implode(' | ', $accInfo) : ($accInfo ?? 'N/A');

                DB::table('transactions')->insert([
                    'user_gmail'     => $data['customer_email'] ?? 'N/A',
                    'method'         => $data['payment_method'] ?? 'UddoktaPay',
                    'sendnumber'     => $data['sender_number'] ?? $displayNumber,
                    'transaction_id' => $data['transaction_id'] ?? $invoiceId,
                    'amount'         => $data['amount'],
                    'order_id'       => $order->id,
                    'page'           => 'Check Out Page',
                    'status'         => 'paid',
                    'time_paid'      => now(),
                    'created_at'     => now(),
                    'updated_at'     => now(),
                ]);

                if ($variation->product->isVoucher()) {
                    $vouchers = Voucher::where('status', Status::AVAILABLE)->where('variation_id', $variation->id)->limit($quantity)->get();
                    foreach ($vouchers as $v) {
                        $v->update(['status' => Status::SOLD, 'order_id' => $order->id]);
                    }
                    $order->update(['voucher_code' => implode(', ', $vouchers->pluck('code')->toArray())]);
                    $variation->decrement('stock', $vouchers->count());
                } else {
                    $variation->decrement('stock', $quantity);
                }

                $this->handleReseller($order);
                
                if ($order->product->isTopup() && $variation->isAutomatic() && gs()->enable_auto_topup) {
                    if (gs()->topup_provider === TopupProvider::HUMAYUN) {
                        $this->sendHumayunWebhook($order);
                    } else {
                        $this->autoTopup($order, $variation->provider_product_id);
                    }
                }

                DB::commit();
                return redirect($variation->product->isVoucher() ? route('codes') : route('orders'))->with('message', 'Order Success.')->with('message_type', 'success');

            } catch (Exception $e) {
                DB::rollBack();
                return redirect()->route('orders')->with('message', 'Order Error: ' . $e->getMessage())->with('message_type', 'error');
            }
        }
        return redirect()->route('orders')->with('message', 'Payment not completed.')->with('message_type', 'error');
    }

    // --- Add Fund Logic ---
    public function addFund(Request $request)
    {
        $user = Auth::user();
        $amount = $request->input('amount');

        if ($amount < 1) {
            return back()->with('message', 'Minimum amount is 1 TK.')->with('message_type', 'error');
        }

        $requestData = [
            'cus_name'    => $user->name,
            'cus_email'   => $user->email,
            'amount'      => $amount,
            'metadata'    => [
                'user_id' => $user->id,
                'type'    => 'add_fund'
            ],
            'success_url' => route('addfund.success'),
            'cancel_url'  => route('cancel.payment'),
        ];

        try {
            $paymentUrl = UddoktaPay::init_payment($requestData);
            return redirect($paymentUrl);
        } catch (Exception $e) {
            return back()->with('message', $e->getMessage())->with('message_type', 'error');
        }
    }

    public function addFundSuccess(Request $request)
    {
        $invoiceId = $request->query('invoice_id') ?? $request->input('invoice_id');
        
        try {
            $data = UddoktaPay::verify_payment($invoiceId);
            
            if (isset($data['status']) && $data['status'] === 'COMPLETED') {
                $metadata = is_array($data['metadata']) ? $data['metadata'] : json_decode($data['metadata'], true);
                
                if (($metadata['type'] ?? null) !== 'add_fund') {
                    return redirect()->route('addfunds')->with('message', 'Invalid metadata.')->with('message_type', 'error');
                }

                DB::beginTransaction();
                try {
                    $user = User::findOrFail($metadata['user_id']);
                    $user->increment('balance', $data['amount']);

                    DB::table('transactions')->insert([
                        'user_gmail'     => $user->email,
                        'method'         => $data['payment_method'] ?? 'UddoktaPay',
                        'sendnumber'     => $data['sender_number'] ?? 'N/A',
                        'transaction_id' => $data['transaction_id'] ?? $invoiceId,
                        'amount'         => $data['amount'],
                        'order_id'       => 'FUND-' . strtoupper(Str::random(8)),
                        'page'           => 'Add fund',
                        'status'         => 'paid',
                        'time_paid'      => now(),
                        'created_at'     => now(),
                        'updated_at'     => now(),
                    ]);

                    DB::commit();
                    return redirect()->route('addfunds')->with('message', 'Balance Added Successfully.')->with('message_type', 'success');

                } catch (Exception $e) {
                    DB::rollBack();
                    return redirect()->route('addfunds')->with('message', 'Error: ' . $e->getMessage())->with('message_type', 'error');
                }
            }
        } catch (Exception $e) {
            return redirect()->route('addfunds')->with('message', 'Verification Failed.')->with('message_type', 'error');
        }
    }

    private function handleReseller(Order $order)
    {
        $user = $order->user;
        if ($user && method_exists($user, 'isReseller') && $user->isReseller()) {
            $percentageAmount = getPercentageAmount($order->amount, $order->product->percentage);
            $user->balance += $percentageAmount;
            $user->save();
        }
    }

    private function autoTopup($order, $name)
    {
        $quantity = 1;
        if (Str::startsWith($name, ['weekly', 'monthly']) && preg_match('/^(weekly|monthly)(\d+)$/i', $name, $matches)) {
            $name = $matches[1];
            $quantity = (int)$matches[2];
        }
        $url = route('auto.topup.webhook') . '?order=' . $order->id;
        Http::withToken(gs()->free_fire_server_api_key)
            ->withHeaders(['Content-Type' => 'application/json'])
            ->post(gs()->free_fire_server_url, [
                'quantity' => $quantity,
                'selectedPackage' => ['id' => 1, 'tag_line' => $name],
                'account_info' => $order->account_info,
                'url' => $url,
                'order_id' => $order->id,
                'user_id' => 'nouser',
            ]);
        $order->status = OrderStatus::AUTOPROCESSING;
        $order->save();
    }

    private function sendHumayunWebhook(Order $order)
    {
        try {
            if ($order->status !== Status::PROCESSING) return;
            $uid = is_array($order->account_info) ? ($order->account_info['player_id'] ?? null) : null;
            if (!$uid) return;

            $payload = [
                'api_key' => gs()->humayun_api_key,
                'order_id' => $order->id,
                'uid' => $uid,
                'variation_name' => $order->variation->title ?? '',
                'status' => $order->status,
            ];

            $webhookUrl = rtrim(gs()->humayun_server_url, '/') . '/webhook/humayun/order';
            Http::timeout(15)->post($webhookUrl, $payload);

            $order->status = OrderStatus::AUTOPROCESSING;
            $order->save();
        } catch (Exception $e) { }
    }

    private function sendNotification($message)
    {
        $botToken = "7326710462:AAFrJM9S7eXMMEEMwsVAWJeIacMH63VbYYk";
        $chatId = "-4810915480";
        Http::post("https://api.telegram.org/bot{$botToken}/sendMessage", [
            'chat_id' => $chatId,
            'text' => $message,
        ]);
        return true;
    }
}