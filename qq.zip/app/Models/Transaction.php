<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
    use HasFactory;

    // এই কলামগুলোতে ডাটা ইনপুট দেওয়ার অনুমতি দেওয়া হলো
    protected $fillable = [
        'user_gmail',
        'method',
        'sendnumber',
        'transaction_id',
        'amount',
        'order_id',
        'page',
        'status',
        'time_paid',
    ];
}