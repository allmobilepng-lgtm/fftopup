<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TopupOf extends Model
{
    use HasFactory;

    protected $fillable = [
        'is_active',
        'player_1',
        'player_2',
        'player_3',
        'player_4',
        'player_5',
    ];
}