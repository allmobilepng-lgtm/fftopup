<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TransactionResource\Pages;
use App\Models\Transaction;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class TransactionResource extends Resource
{
    protected static ?string $model = Transaction::class;

    protected static ?string $navigationIcon = 'heroicon-o-credit-card';
    protected static ?string $navigationGroup = 'Frontend';
    protected static ?string $navigationLabel = 'Transactions';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Transaction Details')
                    ->schema([
                        Forms\Components\TextInput::make('user_gmail')->email()->required(),
                        Forms\Components\TextInput::make('order_id')->required(),
                        
                        // নতুন যুক্ত করা হলো: Page
                        Forms\Components\TextInput::make('page')
                            ->label('Page Name')
                            ->placeholder('e.g. Checkout Page'),

                        Forms\Components\TextInput::make('method')->required(),
                        Forms\Components\TextInput::make('sendnumber')->label('Sender Number')->required(),
                        Forms\Components\TextInput::make('transaction_id')->required()->unique(ignoreRecord: true),
                        Forms\Components\TextInput::make('amount')->numeric()->prefix('BDT')->required(),
                        
                        Forms\Components\Select::make('status')
                            ->options([
                                'paid' => 'Paid',
                                'unpaid' => 'Unpaid',
                            ])->default('unpaid')->required(),
                            
                        Forms\Components\DateTimePicker::make('time_paid'),
                    ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // আইডি কলাম
                Tables\Columns\TextColumn::make('id')
                    ->label('ID')
                    ->sortable(),

                // অর্ডার আইডি
                Tables\Columns\TextColumn::make('order_id')
                    ->label('Order ID')
                    ->searchable()
                    ->sortable(),

                // নতুন যুক্ত করা হলো: Page (টেবিল ভিউতে)
                Tables\Columns\TextColumn::make('page')
                    ->label('Page')
                    ->toggleable()
                    ->searchable(),

                // ইউজার জিমেইল
                Tables\Columns\TextColumn::make('user_gmail')
                    ->label('Email')
                    ->searchable(),

                // পেমেন্ট মেথড
                Tables\Columns\TextColumn::make('method')
                    ->label('Method')
                    ->badge(),

                // যে নাম্বার থেকে টাকা পাঠিয়েছে
                Tables\Columns\TextColumn::make('sendnumber')
                    ->label('Sender No'),

                // ট্রানজেকশন আইডি
                Tables\Columns\TextColumn::make('transaction_id')
                    ->label('Trx ID')
                    ->copyable()
                    ->searchable(),

                // টাকার পরিমাণ
                Tables\Columns\TextColumn::make('amount')
                    ->label('Amount')
                    ->money('BDT'),

                // স্ট্যাটাস ব্যাজ
                Tables\Columns\BadgeColumn::make('status')
                    ->colors([
                        'danger' => 'unpaid',
                        'success' => 'paid',
                    ])
                    ->label('Status'),

                // সময়
                Tables\Columns\TextColumn::make('created_at')
                    ->label('Date')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'paid' => 'Paid',
                        'unpaid' => 'Unpaid',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTransactions::route('/'),
            'create' => Pages\CreateTransaction::route('/create'),
            'edit' => Pages\EditTransaction::route('/{record}/edit'),
        ];
    }
}