<?php

namespace App\Filament\Resources;

use App\Filament\Resources\TopupOfResource\Pages;
use App\Models\TopupOf;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class TopupOfResource extends Resource
{
    protected static ?string $model = TopupOf::class;

    // মেনু আইকন এবং গ্রুপ সেট করা
    protected static ?string $navigationIcon = 'heroicon-o-cpu-chip';
    protected static ?string $navigationGroup = 'Frontend';
    protected static ?string $navigationLabel = 'Topup Off';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('Topup Configuration')
                    ->description('Manage player options and active status')
                    ->schema([
                        // একটিভ বা ইন-একটিভ করার টগল
                        Forms\Components\Toggle::make('is_active')
                            ->label('Active Status')
                            ->default(true)
                            ->required(),

                        // প্লেয়ার অপশনগুলোর ইনপুট ফিল্ড
                        Forms\Components\TextInput::make('player_1')
                            ->label('Player 1')
                            ->placeholder('Enter player 1 detail'),
                        
                        Forms\Components\TextInput::make('player_2')
                            ->label('Player 2'),

                        Forms\Components\TextInput::make('player_3')
                            ->label('Player 3'),

                        Forms\Components\TextInput::make('player_4')
                            ->label('Player 4'),

                        Forms\Components\TextInput::make('player_5')
                            ->label('Player 5'),
                    ])->columns(2), // ফর্মটি দেখতে সুন্দর করার জন্য ২ কলামে ভাগ করা হয়েছে
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                // টেবিল লিস্টে যা যা দেখাবে
                Tables\Columns\IconColumn::make('is_active')
                    ->label('Status')
                    ->boolean(), // টিক মার্ক বা ক্রস মার্ক দেখাবে

                Tables\Columns\TextColumn::make('player_1')
                    ->searchable(),

                Tables\Columns\TextColumn::make('player_2'),

                Tables\Columns\TextColumn::make('updated_at')
                    ->label('Last Update')
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTopupOfs::route('/'),
            'create' => Pages\CreateTopupOf::route('/create'),
            'edit' => Pages\EditTopupOf::route('/{record}/edit'),
        ];
    }
}