<?php

namespace App\Filament\Resources\TopupOfResource\Pages;

use App\Filament\Resources\TopupOfResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditTopupOf extends EditRecord
{
    protected static string $resource = TopupOfResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
