<?php

namespace App\Filament\Resources\TopupOfResource\Pages;

use App\Filament\Resources\TopupOfResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTopupOf extends CreateRecord
{
    protected static string $resource = TopupOfResource::class;
}
