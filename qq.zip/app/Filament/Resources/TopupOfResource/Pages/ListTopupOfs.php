<?php

namespace App\Filament\Resources\TopupOfResource\Pages;

use App\Filament\Resources\TopupOfResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListTopupOfs extends ListRecords
{
    protected static string $resource = TopupOfResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
