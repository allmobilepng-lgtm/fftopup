<?php

namespace App\Filament\Resources;

use App\Constants\OrderStatus;
use App\Filament\Resources\OrderResource\Pages;
use App\Models\Order;
use App\Models\User;
use Filament\Resources\Resource;
use Filament\Forms;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Forms\Form;
use Illuminate\Support\Facades\DB;
use Filament\Tables\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\KeyValue;
use Filament\Forms\Components\Textarea;
use Filament\Tables\Enums\FiltersLayout;
use Illuminate\Database\Eloquent\Builder;

class OrderResource extends Resource
{
    protected static ?string $model = Order::class;
    protected static ?string $navigationIcon = 'heroicon-o-shopping-cart';

    public static function form(Form $form): Form
    {
        $userOptions = User::all()->mapWithKeys(function ($user) {
            return [$user->id => "{$user->name} (ID: {$user->id})"];
        })->toArray();

        return $form
            ->schema([
                Section::make('Order Details')
                    ->schema([
                        Hidden::make('id'),
                        Hidden::make('product_id'),
                        Hidden::make('variation_id'),

                        // Product Title & Variation Info (আগের ডিজাইন)
                        Placeholder::make('product_title')
                            ->label('Product Title')
                            ->content(fn($record) => $record ? "💎 [#{$record->id}] " . ($record->product->title ?? 'N/A') . ' | Variation: ' . ($record->variation->title ?? 'N/A') : 'N/A'),

                        // প্লেয়ার আইডি লজিক: ২ ক্লিকে কপি, ৩ ক্লিকে লগআউট
                        Placeholder::make('player_id_for_copy')
                            ->label('Player ID (Double Click to Copy | Triple Click to Logout)')
                            ->content(function (Order $record) {
                                $info = $record->account_info;
                                if (is_string($info)) $info = json_decode($info, true);
                                return $info['player_id'] ?? 'Player ID Not Found';
                            })
                            ->extraAttributes(function (Order $record) {
                                $info = $record->account_info;
                                if (is_string($info)) $info = json_decode($info, true);
                                $playerId = $info['player_id'] ?? '';
                                return [
                                    'class' => 'cursor-pointer p-2 bg-white border border-gray-300 rounded-lg shadow-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white hover:border-primary-500 transition text-center font-bold',
                                    'ondblclick' => "navigator.clipboard.writeText('{$playerId}'); window.dispatchEvent(new CustomEvent('notification', { detail: { title: 'Player ID Copied!', status: 'success' }}));",
                                    'onclick' => "if (event.detail === 3) { window.open('https://shop.garena.my/logout', '_blank'); }",
                                ];
                            })
                            ->columnSpanFull(),
                            
                        Select::make('status')
                            ->options(OrderStatus::options())
                            ->required(),

                        // --- Advanced Details (সবগুলো এখন এর পেটের ভেতর) ---
                        Section::make('Advanced Details (Click to Expand)')
                            ->description('User, Account, and Transaction Information')
                            ->collapsible()
                            ->collapsed()
                            ->schema([
                                
                                // ১. User Name
                                Select::make('user_id')
                                    ->label('User Name *')
                                    ->options($userOptions)
                                    ->searchable()
                                    ->required(),

                                // ২. Account Info & Delivery Message
                                KeyValue::make('account_info') 
                                    ->label('Account Info (Editable)') 
                                    ->keyLabel('Key')
                                    ->valueLabel('Value'),

                                Textarea::make('delivery_message')
                                    ->label('Delivery Message')
                                    ->rows(3),

                                // ৩. Transaction Details (সরাসরি টেবিল থেকে আইডি নিয়ে আসবে)
                                Section::make('Transaction Details')
                                    ->compact()
                                    ->schema([
                                        Placeholder::make('transaction_info')
                                            ->label('')
                                            ->content(function (Order $record) {
                                                $transaction = DB::table('transactions')->where('order_id', $record->id)->first();
                                                if (!$transaction) return "No transaction record found.";

                                                return new \Illuminate\Support\HtmlString("
                                                    <div style='font-size: 0.9rem; line-height: 1.6;'>
                                                        <strong>Trx ID:</strong> {$transaction->transaction_id} <br>
                                                        <strong>Method:</strong> {$transaction->method} <br>
                                                        <strong>Sender:</strong> {$transaction->sendnumber} <br>
                                                        <strong>Amount:</strong> ৳{$transaction->amount}
                                                    </div>
                                                ");
                                            }),
                                    ]),
                            ]),
                    ])
                    ->columns(2),
            ]);
    }

    // Table অংশ আগের মতোই থাকবে...
    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id')->label('ID')->sortable()->searchable(),
                Tables\Columns\TextColumn::make('user.name')->label('User Name')->sortable(),
                Tables\Columns\TextColumn::make('product.title')->label('Product')->sortable(),
                Tables\Columns\TextColumn::make('amount')->label('Amount')->sortable(),
                Tables\Columns\TextColumn::make('status')->badge(),
                Tables\Columns\TextColumn::make('created_at')->label('Order Date')->dateTime()->sortable(),
            ])
            ->defaultSort('id', 'desc')
            ->actions([
                Tables\Actions\EditAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListOrder::route('/'),
            'edit' => Pages\EditOrder::route('/{record}/edit'),
        ];
    }
}