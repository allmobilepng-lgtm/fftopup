<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->string('user_gmail'); // ইউজারের জিমেইল
            $table->string('method'); // পেমেন্ট মেথড (যেমন: bKash, Nagad)
            $table->string('sendnumber'); // যে নাম্বার থেকে টাকা পাঠানো হয়েছে
            $table->string('transaction_id')->unique(); // ইউনিক ট্রানজেকশন আইডি
            $table->decimal('amount', 10, 2); // টাকার পরিমাণ
            $table->string('order_id'); // অর্ডার আইডি
            $table->string('page')->nullable(); // আপনি এই অপশনটি চেয়েছিলেন
            
            // স্ট্যাটাস ফিল্ড (ডিফল্ট unpaid থাকবে)
            $table->enum('status', ['paid', 'unpaid'])->default('unpaid'); 
            
            $table->timestamp('time_paid')->nullable(); // পেমেন্টের সময়
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transactions');
    }
};