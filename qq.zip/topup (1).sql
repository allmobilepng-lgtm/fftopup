-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2026 at 05:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `topup`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3', 'i:1;', 1769444580),
('livewire-rate-limiter:a17961fa74e9275d529f489537f179c05d50c2f3:timer', 'i:1769444580;', 1769444580);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slot` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`, `slot`, `status`, `created_at`, `updated_at`) VALUES
(1, 'FREE FIRE  ', '1', '1', '2025-06-10 12:15:08', '2025-06-10 12:15:08');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '2025_02_24_173156_create_details_table', 1),
(5, '2025_02_26_094407_create_banners_table', 1),
(6, '2025_03_12_183145_create_vouchers_table', 1),
(7, '2025_06_07_091342_create_categories_table', 1),
(8, '2025_06_07_092015_create_products_table', 1),
(9, '2025_06_07_092233_create_variations_table', 1),
(10, '2025_06_07_093847_create_orders_table', 2),
(11, '2025_06_07_140012_create_settings_table', 3),
(12, '2024_01_16_060402_create_general_settings', 4),
(13, '2025_06_08_111910_create_sliders_table', 5),
(14, '2024_01_05_131543_create_popups_table', 6),
(15, '2026_01_17_065115_add_topup_to_of_settings', 7),
(16, '2026_01_17_071131_add_telegram_notification_settings', 8),
(17, '2026_01_17_095202_create_topup_to_of_table', 9),
(18, '2026_01_17_162524_add_account_info_to_orders_table', 10),
(19, '2026_01_17_163343_create_orders_table', 11),
(20, '2026_01_17_163819_add_account_info_to_orders_table', 12);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_info_to` varchar(255) DEFAULT NULL,
  `account_info_original` varchar(255) DEFAULT NULL,
  `order_id_to` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `variation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `profit` decimal(16,2) NOT NULL DEFAULT 0.00,
  `delivery_message` text DEFAULT NULL,
  `account_info` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`account_info`)),
  `provider_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`provider_data`)),
  `voucher_code` varchar(255) DEFAULT NULL,
  `track_id` varchar(25) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `attempts` tinyint(4) NOT NULL DEFAULT 0,
  `status` enum('complete','processing','auto-processing','cancel') NOT NULL DEFAULT 'processing',
  `claimed` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`email`, `token`, `created_at`) VALUES
('antorh545@gmail.com', '$2y$12$x.KK/3BnBdJMjVPtjmfXLe9kcwrTPl8f57HbbRRQjm59GeDngd4c.', '2025-08-14 17:06:55'),
('bhayankarabot@gmail.com', '$2y$12$Hv6lAOZQN/mFFjTC70EeZ.qGraXelf2Y871RHYtjjAbJFwURGyOtG', '2025-08-14 20:10:24'),
('fardoushmondol0123@gmail.com', '$2y$12$Ql7U9/3qPpdtTmc1OB6le.qhoF1P2qKOKTrwa2tCs.Go.9hWU723G', '2025-06-24 14:47:16'),
('md.rotonmia2020@gmail.com', '$2y$12$s3xsGq0uxVLIhPpCpISQqeBuoRXHml0LrkJaN5Q4tVaATVnlc1aoG', '2025-08-03 22:42:06'),
('mdh346367@gmail.com', '$2y$12$3Eds8IlJ3/95RrpVKVsRMOnGoaq./rSF73CAm9UpMWtZcJpFv8Vye', '2025-06-19 14:27:15'),
('mdimranchowdhury87@gmail.com', '$2y$12$CoWkO4TQv.ovji77KS362OAeBsRzlzax6tdXPd4hqvLRjfX0k1Hw2', '2025-08-12 06:46:48'),
('mdsiyam425809@gmail.com', '$2y$12$iovxEjpT0NfzGMNdw/wVEejUMTDoTiQOLbtLzUSoIfNJtjFK1mBAS', '2025-08-13 22:08:37'),
('mkminhaj177@gmail.com', '$2y$12$P/uRKKn2lS8lSatiZmvxKugDyYOPSnpKCRGjuRLtOQ5CnChvEs8fy', '2025-08-06 08:51:26'),
('mrxxx3235@gmail.com', '$2y$12$h0pvE1EkOgpFhvQZG1LDUu2yvpwqkXq10NrdHYNRes7IxuyRKGNqC', '2025-12-22 20:48:13'),
('olifarazi35@gmail.com', '$2y$12$Ld222BQjJF1k3/P80FiJN.8d3UZXgbyzBzVidKr3jtMdiGIZLaxC2', '2025-06-19 13:14:39'),
('P3066904@gmail.com', '$2y$12$IROSAbwTsU/tL57EoChYzeBSF6LpapQqI.yxmuq9RBRxnv4hPwmJq', '2025-07-09 19:28:50'),
('r36390014@gmail.com', '$2y$12$dkpwnbg/LQeE0j9Jbxao5eOc3SwjZ3LKznFSLkDoi4TvUQyhbgciy', '2025-07-12 20:07:22'),
('sakia4567777@gmail.com', '$2y$12$s6tyurVJeB21K8wtG85cSuX6kzYwvpxVQ.CWXSRQZGEfY9jZEgvd6', '2025-07-11 19:09:17'),
('sksalammiya520@gmail.com', '$2y$12$bYgqsqK7Lmw0szOfDIv7denukUy6Yy7X0A.2ZfjHgQy1Hvn6cuTmu', '2025-06-16 16:15:30'),
('sohagmahamud2017@gmail.com', '$2y$12$bXJyHwMP2DMva/0Au9JtfOA3LkZUcsSV5BCr23dJqCwXYQK9a0PN.', '2025-06-16 16:44:43'),
('sojimd302@gmail.com', '$2y$12$Z39mNYpHm4GX.Ybm5SEujORz3tSUPaHAkPEVgUZgIFy.d5JEfdy5C', '2026-01-10 16:26:30'),
('tanverbhuiyan4@gmail.com', '$2y$12$MyhxMq0fbO01DJNDYdSEKeX17yuNJo0cntGuAMn2t3b2BgeAvjoWC', '2025-07-27 12:16:00'),
('urnyejy48@gmail.com', '$2y$12$knpktLEiwRUwpnQvAX3Ha.ZmyQAmr4RCLex5WTigzl4h5j9Hl2P9S', '2025-12-19 14:14:02');

-- --------------------------------------------------------

--
-- Table structure for table `popups`
--

CREATE TABLE `popups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `button_text` varchar(255) DEFAULT NULL,
  `type` enum('once','daily') NOT NULL DEFAULT 'once',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` text NOT NULL,
  `slug` varchar(255) NOT NULL,
  `categorie_id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `type` enum('INGAME','IDCODE','VOUCHER','SUBSCRIPTION') NOT NULL,
  `percentage` int(11) DEFAULT 0,
  `uid_checker` tinyint(1) NOT NULL DEFAULT 0,
  `has_tutorial` tinyint(1) NOT NULL DEFAULT 0,
  `tutorial_link` varchar(1050) DEFAULT NULL,
  `tutorial_text` varchar(1050) DEFAULT NULL,
  `image` text NOT NULL,
  `slot` int(11) NOT NULL DEFAULT 1,
  `input` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `slug`, `categorie_id`, `content`, `type`, `percentage`, `uid_checker`, `has_tutorial`, `tutorial_link`, `tutorial_text`, `image`, `slot`, `input`, `status`, `created_at`, `updated_at`) VALUES
(1, 'UID TOPUP BD SERVER', 'uid-topup-bd-server', 1, '<p>⦿ শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।</p><p>&nbsp;</p><p>⦿ Player ID Code ভুল দিয়ে Diamond না পেলে কর্তৃপক্ষ দায়ী নয়।</p><p>&nbsp;</p><p>⦿ Order কমপ্লিট হওয়ার পরেও আইডিতে ডাইমন্ড না গেলে সাপোর্টে মেসেজ দিন।</p><p>&nbsp;</p><p>⦿ অর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টোরিতে দেওয়া থাকে অনুগ্রহ পুর্বক দেখে পুনরায় সঠিক তথ্য দিয়ে অর্ডার করবেন।</p>', 'IDCODE', 0, 0, 0, NULL, NULL, 'products/01JY1FJ86CRPJBWSH0G467QSWZ.jpg', 1, 'এখানে আপনার (UID) আইডি কোড দিন ! ', 1, '2025-06-10 12:15:18', '2025-06-18 22:46:41'),
(2, 'Unipin Voucher [BD]', 'unipin-voucher-bd', 1, '<p>#</p>', 'VOUCHER', 0, 0, 0, NULL, NULL, 'products/01JY1FYZJKTGMESYCAZR9JJW6T.webp', 2, 'আপনার আইডি কোড দিন', 1, '2025-06-15 15:30:40', '2025-06-18 18:24:31'),
(3, 'Weekly&Monthly', 'weeklymonthly', 1, '<p>⦿ শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।</p><p>&nbsp;</p><p>⦿ Player ID Code ভুল দিয়ে Diamond না পেলে কর্তৃপক্ষ দায়ী নয়।</p><p>&nbsp;</p><p>⦿ Order কমপ্লিট হওয়ার পরেও আইডিতে ডাইমন্ড না গেলে সাপোর্টে মেসেজ দিন।</p><p>&nbsp;</p><p>⦿ অর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টোরিতে দেওয়া থাকে অনুগ্রহ পুর্বক দেখে পুনরায় সঠিক তথ্য দিয়ে অর্ডার করবেন।</p>', 'IDCODE', 0, 0, 0, NULL, NULL, 'products/01JY1G0FDEG2VHWN3PGYR60WY6.jpg', 4, 'এখানে আপনার (UID) আইডি কোড দিন !', 1, '2025-06-15 15:35:41', '2025-06-18 22:47:12'),
(4, 'Level Up Pass', 'level-up-pass', 1, '<p>⦿ শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।</p><p>&nbsp;</p><p>⦿ Player ID Code ভুল দিয়ে Diamond না পেলে কর্তৃপক্ষ দায়ী নয়।</p><p>&nbsp;</p><p>⦿ Order কমপ্লিট হওয়ার পরেও আইডিতে ডাইমন্ড না গেলে সাপোর্টে মেসেজ দিন।</p><p>&nbsp;</p><p>⦿ অর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টোরিতে দেওয়া থাকে অনুগ্রহ পুর্বক দেখে পুনরায় সঠিক তথ্য দিয়ে অর্ডার করবেন।</p>', 'IDCODE', 0, 0, 0, NULL, NULL, 'products/01JXSFDW01GC4YPD5CJT46NY11.png', 3, 'এখানে আপনার (UID) আইডি কোড দিন ! ', 1, '2025-06-15 15:41:15', '2025-06-18 22:47:33'),
(5, 'Weekly Lite (BD Server)', 'weekly-lite-bd-server', 1, '<p>#</p>', 'IDCODE', 0, 0, 0, NULL, NULL, 'products/01JY1G24XP1BCSPFG612JJFF4K.jpg', 5, 'এখানে আপনার (UID) আইডি কোড দিন ! ', 1, '2025-06-15 15:43:08', '2025-06-18 18:26:15'),
(6, 'EVO ACCESS BD [UID]', 'evo-access-bd-uid', 1, '<p>⦿ শুধুমাত্র Bangladesh সার্ভারে ID Code দিয়ে টপ আপ হবে।</p><p>&nbsp;</p><p>⦿ Player ID Code ভুল দিয়ে Diamond না পেলে কর্তৃপক্ষ দায়ী নয়।</p><p>&nbsp;</p><p>⦿ Order কমপ্লিট হওয়ার পরেও আইডিতে ডাইমন্ড না গেলে সাপোর্টে মেসেজ দিন।</p><p>&nbsp;</p><p>⦿ অর্ডার Cancel হলে কি কারণে তা Cancel হয়েছে তা অর্ডার হিস্টোরিতে দেওয়া থাকে অনুগ্রহ পুর্বক দেখে পুনরায় সঠিক তথ্য দিয়ে অর্ডার করবেন।</p>', 'IDCODE', 0, 0, 0, NULL, NULL, 'products/01JY1GA78KV6QF3FJ7RCJW6DFB.jpg', 7, 'এখানে আপনার (UID) আইডি কোড দিন ! ', 1, '2025-06-15 15:44:03', '2025-06-18 22:47:49');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('HkhgU8Yl3nLguMtYE8Pquyfp8WsrlAHD8xCwPpcH', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYzBkMncxUldiS3hZTzF2NW5zYUdLQjlGNnlKbDdaRWRRbzE4U2VDbyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9tYW5pZmVzdC5qc29uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769444450),
('iL2PA97hbHKWofZM3gzJMnooS76JZBAgUKIt0aO1', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiV1VPM2JjaVZNeGZaWTd4RjVLb244MjBJTWpwTGV2alZ0WmJlVmwzOSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjk6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hY2NvdW50Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMiRVVkRsYURZV3RaVjBML2MuZ2Jydi51ZENGZUUzNGpnUkpaZGxvSUk0b3F1dXhHQWUvSkhVLiI7fQ==', 1769445020),
('omS4KFjxMSYsqVTvjEGwtcqNVi3uGyH6GOVlfZ0K', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaXJienhIN0lDSjJIeHk1VHhCWk12TERocktpb1l5MkZBU1pUSUx4YyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9tYW5pZmVzdC5qc29uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769444916),
('QLue0XpZ3L3mvIciuDUdZkYgCa4RGSz8fltLE4oS', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQXJnUGdNRGR5TEZRMEZhU2ZTQ0ludHIyWElqMElONlJDVXNpUVhsaiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9tYW5pZmVzdC5qc29uIjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1769445025);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `group` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`payload`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `group`, `name`, `locked`, `payload`, `created_at`, `updated_at`) VALUES
(1, 'general', 'site_name', 0, '\"tast\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(2, 'general', 'site_title', 0, '\"tast\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(3, 'general', 'home_title', 0, '\"tast\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(4, 'general', 'paginate_per_page', 0, '10', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(5, 'general', 'logo', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(6, 'general', 'favicon', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(7, 'general', 'add_money_video_link', 0, '\"https:\\/\\/youtu.be\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(8, 'general', 'backup_code_video_link', 0, '\"#\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(9, 'general', 'tutorial_video_link', 0, '\"#\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(10, 'general', 'google_client_id', 0, '\"tast\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(11, 'general', 'google_client_secret', 0, '\"tast\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(12, 'general', 'header_tags', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(13, 'general', 'footer_js', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(14, 'general', 'wallet', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(15, 'general', 'smtp_from_address', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(16, 'general', 'smtp_host', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(17, 'general', 'smtp_port', 0, '587', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(18, 'general', 'smtp_username', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(19, 'general', 'smtp_password', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(20, 'general', 'uddoktapay_api_key', 0, '\"#\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(21, 'general', 'uddoktapay_api_url', 0, '\"#\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(22, 'general', 'uddoktapay_min_amount', 0, '0', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(23, 'general', 'uddoktapay_max_amount', 0, '10000', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(24, 'general', 'facebook_link', 0, '\"https:\\/\\/facebook.com\\/\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(25, 'general', 'youtube_link', 0, '\"https:\\/\\/youtube.com\\/\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(26, 'general', 'messenger_link', 0, '\"https:\\/\\/m.me\\/\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(27, 'general', 'whatsapp_number', 0, '\"https:\\/\\/t.me\\/MS2BD_BOT\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(28, 'general', 'support_number', 0, '\"https:\\/\\/t.me\\/MS2BD_BOT\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(29, 'general', 'email_address', 0, '\"admin@gmail.com\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(30, 'general', 'support_time', 0, '\"9AM - 10PM\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(31, 'general', 'background_image', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(32, 'general', 'footer_menu', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(33, 'general', 'theme_color', 0, '\"#370373\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(34, 'general', 'logo_color', 0, '\"#424242\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(35, 'general', 'background_color', 0, '\"#f8f9fc\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(36, 'general', 'font_color', 0, '\"#000000\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(37, 'general', 'navigation_background_color', 0, '\"#ffffff\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(38, 'general', 'navigation_font_color', 0, '\"#000000\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(39, 'general', 'footer_color', 0, '\"#370373\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(40, 'general', 'footer_font_color', 0, '\"#ffffff\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(41, 'general', 'content_box_color', 0, '\"#ffffff\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(42, 'general', 'notice_background_color', 0, '\"#370373\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(43, 'general', 'notice_font_color', 0, '\"#ffffff\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(44, 'general', 'seo_description', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(45, 'general', 'seo_keywords', 0, '\"TopuPbd,FF TOPUOBD,UCTOPUP,TopUp bd\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(46, 'general', 'fb_og_image', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(47, 'general', 'twitter_og_image', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(48, 'general', 'enable_notice', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(49, 'general', 'notice_title', 0, '\"Notice:\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(50, 'general', 'notice_content', 0, '\"\\u09b8\\u09c1-\\u0996\\u09ac\\u09b0 ! \\u098f\\u0996\\u09a8 \\u09a5\\u09c7\\u0995\\u09c7 \\u09a6\\u09bf\\u09a8-\\u09b0\\u09be\\u09a4 24 \\u0998\\u09a8\\u09cd\\u099f\\u09be \\u099f\\u09aa-\\u0986\\u09aa \\u0995\\u09b0\\u09b2\\u09c7 \\u0985\\u099f\\u09cb\\u09ae\\u09c7\\u099f\\u09bf\\u0995 \\u09a1\\u09c7\\u09b2\\u09bf\\u09ad\\u09be\\u09b0\\u09bf \\u09b9\\u09df\\u09c7 \\u09af\\u09be\\u09ac\\u09c7\\u0964 \\u09b8\\u09a0\\u09bf\\u0995 \\u0986\\u0987\\u09a1\\u09bf \\u0995\\u09cb\\u09a1\\u09c7 \\u0985\\u09b0\\u09cd\\u09a1\\u09be\\u09b0 \\u0995\\u09b0\\u09b2\\u09c7 \\u09e7\\u09e6\\u09b8\\u09c7\\u0995\\u09c7\\u09a8\\u09cd\\u09a1\\u09c7 \\u09a1\\u09c7\\u09b2\\u09bf\\u09ad\\u09be\\u09b0\\u09bf \\u0964 \"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(51, 'general', 'base_currency', 0, '\"BDT\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(52, 'general', 'currency_symbol', 0, '\"\\u09f3\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(53, 'general', 'enable_pwa', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(54, 'general', 'pwa_icon', 0, 'null', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(55, 'general', 'enable_uid_checker', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(56, 'general', 'enable_auto_topup', 0, 'true', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(57, 'general', 'topup_provider', 0, '\"Humayun\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(58, 'general', 'free_fire_server_url', 0, '\"https:\\/\\/botclient.gamesbazarbd.com\\/api\\/resaleorder\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(59, 'general', 'free_fire_server_api_key', 0, '\"cmbyrvniq0000cas89qtm4rqn\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(60, 'general', 'version', 0, '\"1.1.3\"', '2025-06-07 08:05:20', '2026-01-21 23:11:54'),
(424, 'general', 'telegram_link', 0, '\"https:\\/\\/t.me\\/MS2BD_BOT\"', '2025-06-09 08:05:20', '2026-01-21 23:11:54'),
(6860, 'general', 'humayun_server_url', 0, '\"https:\\/\\/bot.vnbazer.com\"', '2025-12-01 17:51:01', '2026-01-21 23:11:54'),
(6861, 'general', 'humayun_api_key', 0, '\"qSkDiWlMDEGtzqDHfhZTttms2bd\"', '2025-12-01 17:51:01', '2026-01-21 23:11:54'),
(7114, 'coin', 'coin_to_taka', 0, '\"7\"', '2025-12-04 16:34:38', '2025-12-22 12:20:34'),
(11778, 'general', 'topup_to_of', 0, 'true', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11779, 'general', 'balance_detect', 0, '\"100\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11780, 'general', 'player_id_1', 0, '\"1\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11781, 'general', 'player_id_2', 0, '\"2\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11782, 'general', 'player_id_3', 0, '\"3\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11783, 'general', 'player_id_4', 0, '\"4\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11784, 'general', 'player_id_5', 0, '\"5\"', '2026-01-17 00:53:24', '2026-01-17 03:45:15'),
(11925, 'general', 'botToken_1', 0, '\"8395934575:AAFXmaL5Mbq8KPNJUgJ9cEQXN38HfJQQ89E\"', '2026-01-17 01:15:12', '2026-01-21 23:11:54'),
(11926, 'general', 'chatId_1', 0, '\"-4741918127\"', '2026-01-17 01:15:12', '2026-01-21 23:11:54'),
(11927, 'general', 'botToken_2', 0, '\"8395934575:AAFXmaL5Mbq8KPNJUgJ9cEQXN38HfJQQ89E\"', '2026-01-17 01:15:12', '2026-01-21 23:11:54'),
(11928, 'general', 'chatId_2', 0, '\"-5254616287\"', '2026-01-17 01:15:12', '2026-01-21 23:11:54');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `image_url` varchar(300) NOT NULL,
  `order_column` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topup_to_of`
--

CREATE TABLE `topup_to_of` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `balance_detect` decimal(10,2) NOT NULL DEFAULT 0.00,
  `player_id_1` varchar(255) DEFAULT NULL,
  `player_id_2` varchar(255) DEFAULT NULL,
  `player_id_3` varchar(255) DEFAULT NULL,
  `player_id_4` varchar(255) DEFAULT NULL,
  `player_id_5` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `topup_to_of`
--

INSERT INTO `topup_to_of` (`id`, `status`, `balance_detect`, `player_id_1`, `player_id_2`, `player_id_3`, `player_id_4`, `player_id_5`, `created_at`, `updated_at`) VALUES
(1, 1, 290.00, '2895241006', '2895241006', '2895241006', '2895241006', '2895241006', '2026-01-17 04:00:48', '2026-01-19 09:58:49');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `user_gmail` varchar(255) DEFAULT NULL,
  `method` varchar(50) NOT NULL,
  `transaction_id` varchar(100) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `page` varchar(255) DEFAULT NULL,
  `order_id` int(10) UNSIGNED DEFAULT NULL,
  `time_paid` datetime DEFAULT NULL,
  `unpaid` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `picture` text DEFAULT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user' COMMENT 'user, admin, reseller',
  `balance` varchar(255) NOT NULL DEFAULT '0',
  `coins` varchar(255) NOT NULL DEFAULT '0',
  `total_order` varchar(255) NOT NULL DEFAULT '0',
  `total_spent` varchar(255) NOT NULL DEFAULT '0',
  `total_refer` int(11) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) DEFAULT NULL,
  `is_reseller` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `referral_code` varchar(20) DEFAULT NULL,
  `referred_by` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `picture`, `user_type`, `balance`, `coins`, `total_order`, `total_spent`, `total_refer`, `remember_token`, `is_reseller`, `status`, `referral_code`, `referred_by`, `created_at`, `updated_at`) VALUES
(1, 'ADMIN', 'admin@gmail.com', '01999999999', '$2y$12$UVDlaDYWtZV0L/c.gbrv.udCFeE34jgRJZdloII4oquuxGAe/JHU.', 'https://ui-avatars.com/api/?name=A&size=96&background=f29f2c', 'admin', '0', '0', '0', '0', 0, 'mvXbHyJdBsLHsz8NjxtoxFXSNEGkN2rwLisBFDjGsPOW3LyHtgG8wg7Sm45q', 0, 1, 'GMHJPGLG', NULL, '2026-01-20 07:25:54', '2026-01-20 07:25:54');

-- --------------------------------------------------------

--
-- Table structure for table `variations`
--

CREATE TABLE `variations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(16,2) NOT NULL DEFAULT 0.00,
  `buy_rate` decimal(16,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `automatic` tinyint(4) NOT NULL DEFAULT 0,
  `provider` varchar(255) DEFAULT NULL,
  `provider_product_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `variations`
--

INSERT INTO `variations` (`id`, `product_id`, `title`, `price`, `buy_rate`, `stock`, `automatic`, `provider`, `provider_product_id`, `created_at`, `updated_at`) VALUES
(1, 1, '25 Diamond ', 19.00, 18.00, 19999317, 1, 'FreeFire', '25', '2025-06-12 22:54:20', '2026-01-21 08:58:07'),
(2, 1, '50 Diamond', 33.00, 32.00, 199999695, 1, 'FreeFire', '50', '2025-06-15 19:23:22', '2026-01-20 18:57:04'),
(3, 1, '115 Diamond', 69.00, 73.00, 19999696, 1, 'FreeFire', '115', '2025-06-15 19:23:55', '2026-01-17 13:23:50'),
(4, 1, '240 Diamond', 139.00, 149.00, 19999948, 1, 'FreeFire', '240', '2025-06-15 19:24:34', '2025-12-31 10:13:15'),
(5, 1, '355 Diamond', 215.00, 210.00, 1999999949, 0, 'FreeFire', '355', '2025-06-15 19:26:06', '2026-01-13 12:40:30'),
(6, 1, '480 Diamond', 280.00, 275.00, 499999973, 0, NULL, NULL, '2025-06-15 19:27:55', '2025-12-27 13:37:04'),
(7, 1, '610 Diamond', 330.00, 345.00, 199999944, 0, NULL, NULL, '2025-06-15 19:43:26', '2026-01-02 17:45:34'),
(8, 1, '850 Diamond', 445.00, 445.00, 19999984, 0, NULL, NULL, '2025-06-15 19:45:25', '2025-12-30 20:53:39'),
(9, 1, '1090 Diamond', 560.00, 610.00, 19999961, 0, NULL, NULL, '2025-06-15 19:50:39', '2026-01-15 19:48:02'),
(10, 1, '1240 Diamond', 610.00, 620.00, 19999991, 0, NULL, NULL, '2025-06-15 19:50:59', '2025-10-26 03:39:43'),
(11, 1, '1595 Diamond', 880.00, 900.00, 2000000000, 0, NULL, NULL, '2025-06-15 19:52:15', '2025-10-21 02:49:54'),
(12, 1, '1850 Diamond', 1030.00, 975.00, 20000000, 0, NULL, NULL, '2025-06-15 19:53:15', '2025-10-21 02:49:54'),
(13, 1, ' 2090 Diamond', 1150.00, 1150.00, 20000000, 0, NULL, NULL, '2025-06-15 19:55:03', '2025-10-21 02:50:07'),
(15, 1, '2530 Diamond', 1370.00, 1270.00, 19999997, 0, NULL, NULL, '2025-06-15 19:56:25', '2025-10-21 02:50:07'),
(16, 1, '3140 Diamond', 1690.00, 1699.00, 19999999, 0, NULL, NULL, '2025-06-15 19:58:28', '2025-10-21 02:50:07'),
(17, 1, '3770 Diamond', 1980.00, 2050.00, 19999998, 0, NULL, NULL, '2025-06-15 19:59:43', '2025-12-05 09:34:57'),
(18, 1, '5060 Diamond', 2499.00, 2550.00, 19999994, 0, NULL, NULL, '2025-06-15 20:00:38', '2025-12-29 11:45:50'),
(19, 1, '10120 Diamond', 4499.00, 5410.00, 1999997, 0, NULL, NULL, '2025-06-15 20:02:10', '2025-12-28 14:59:50'),
(20, 1, 'Weekly Lite', 45.00, 38.00, 19999791, 1, 'FreeFire', 'LITE', '2025-06-15 20:07:13', '2026-01-15 14:52:29'),
(21, 1, 'Weekly ', 139.00, 140.00, 199998537, 1, 'FreeFire', '161', '2025-06-15 20:07:29', '2026-01-21 11:15:45'),
(22, 1, 'Monthly', 610.00, 670.00, 19999620, 0, NULL, NULL, '2025-06-15 20:08:01', '2026-01-19 17:32:58'),
(33, 4, '6 level (120 Diamond)', 45.00, 38.00, 19999950, 0, 'FreeFire', '108588', '2025-06-15 20:21:46', '2026-01-06 10:19:18'),
(34, 4, '10 level (200 Diamond)', 75.00, 70.00, 19999986, 0, NULL, NULL, '2025-06-15 20:22:06', '2025-12-10 18:00:43'),
(35, 4, '15 level (200 Diamond)', 75.00, 70.00, 19999989, 0, NULL, NULL, '2025-06-15 20:22:33', '2025-10-29 18:34:00'),
(36, 4, '20 level (200 Diamond) ৳ 70', 75.00, 70.00, 1999989, 0, NULL, NULL, '2025-06-15 20:22:52', '2025-11-18 23:12:14'),
(37, 4, '25 level (200 Diamond)', 75.00, 70.00, 19999991, 0, NULL, NULL, '2025-06-15 20:23:07', '2025-11-06 20:26:16'),
(38, 4, '30 level (200 Diamond)', 105.00, 100.00, 19999984, 0, NULL, NULL, '2025-06-15 20:23:30', '2026-01-13 16:32:23'),
(39, 4, 'Level Up Pass Full (1270 Diamond) ৳ 400', 385.00, 380.00, 37999976, 0, NULL, NULL, '2025-06-15 20:23:55', '2026-01-16 18:51:35'),
(40, 5, 'Weekly Lite', 45.00, 38.00, 4999969, 1, 'FreeFire', 'LITE', '2025-06-15 20:25:26', '2025-12-29 21:21:45'),
(41, 6, '3 Days Evo Access', 70.00, 70.00, 1999999, 0, NULL, NULL, '2025-06-15 20:26:22', '2025-08-20 15:41:49'),
(42, 6, '7 Days Evo Access', 100.00, 100.00, 19999998, 0, NULL, NULL, '2025-06-15 20:26:39', '2025-06-19 20:46:21'),
(43, 6, '30 Days Evo Access', 290.00, 290.00, 19999999, 0, NULL, NULL, '2025-06-15 20:27:29', '2025-06-21 10:26:19');

-- --------------------------------------------------------

--
-- Table structure for table `vouchers`
--

CREATE TABLE `vouchers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `variation_id` int(10) UNSIGNED NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD UNIQUE KEY `password_reset_tokens_email_unique` (`email`);

--
-- Indexes for table `popups`
--
ALTER TABLE `popups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_slug_unique` (`slug`),
  ADD KEY `products_categorie_id_foreign` (`categorie_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_group_name_unique` (`group`,`name`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topup_to_of`
--
ALTER TABLE `topup_to_of`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `variations`
--
ALTER TABLE `variations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `variations_product_id_foreign` (`product_id`);

--
-- Indexes for table `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vouchers_variation_id_foreign` (`variation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `popups`
--
ALTER TABLE `popups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14786;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topup_to_of`
--
ALTER TABLE `topup_to_of`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `variations`
--
ALTER TABLE `variations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_categorie_id_foreign` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `variations`
--
ALTER TABLE `variations`
  ADD CONSTRAINT `variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
